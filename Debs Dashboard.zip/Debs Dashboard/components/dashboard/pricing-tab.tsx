"use client"

import { useMemo } from "react"
import {
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ScatterChart,
  Scatter,
  ZAxis,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import { getProductSummaries } from "@/lib/analytics/product-analytics"
import {
  getPricingInsights,
  getAvgTransactionTrend,
} from "@/lib/analytics/pricing-analytics"

const avgValueConfig: ChartConfig = {
  avgValue: { label: "Avg Transaction Value", color: "var(--color-chart-1)" },
}

const scatterConfig: ChartConfig = {
  products: { label: "Product", color: "var(--color-chart-2)" },
}

export function PricingTab({ data }: { data: DashboardData }) {
  const products = useMemo(
    () => getProductSummaries(data.squareItems),
    [data.squareItems]
  )
  const insights = useMemo(
    () => getPricingInsights(products),
    [products]
  )
  const avgTrend = useMemo(
    () => getAvgTransactionTrend(products),
    [products]
  )

  const increaseRecs = insights.filter((i) => i.recommendation === "increase")
  const decreaseRecs = insights.filter((i) => i.recommendation === "decrease")

  // Scatter: price vs quantity
  const scatterData = products.map((p) => ({
    name: p.item,
    avgPrice: Math.round(p.avgPrice * 100) / 100,
    totalQty: p.totalQty,
    revenue: p.totalRevenue,
  }))

  return (
    <div className="flex flex-col gap-6">
      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Products Analyzed</CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              {insights.length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Price Increase Opportunities</CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums text-chart-2">
              {increaseRecs.length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Price Decrease Candidates</CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums text-chart-5">
              {decreaseRecs.length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Average transaction value trend */}
      <Card>
        <CardHeader>
          <CardTitle>Average Transaction Value</CardTitle>
          <CardDescription>
            How average price per item has changed over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={avgValueConfig} className="h-[280px] w-full">
            <LineChart data={avgTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${v.toFixed(0)}`}
                domain={["auto", "auto"]}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toFixed(2)}`
                    }
                  />
                }
              />
              <Line
                type="monotone"
                dataKey="avgValue"
                stroke="var(--color-chart-1)"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Price vs Demand scatter */}
      <Card>
        <CardHeader>
          <CardTitle>Price vs Demand</CardTitle>
          <CardDescription>
            Bubble size represents total revenue. Identify high-demand low-price
            items (bottom right) and low-demand high-price items (top left).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={scatterConfig} className="h-[320px] w-full">
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="totalQty"
                type="number"
                tickLine={false}
                axisLine={false}
                name="Units Sold"
                label={{
                  value: "Units Sold",
                  position: "insideBottom",
                  offset: -5,
                  style: { fontSize: 12 },
                }}
              />
              <YAxis
                dataKey="avgPrice"
                type="number"
                tickLine={false}
                axisLine={false}
                name="Avg Price"
                tickFormatter={(v) => `$${v}`}
                label={{
                  value: "Avg Price",
                  angle: -90,
                  position: "insideLeft",
                  style: { textAnchor: "middle", fontSize: 12 },
                }}
              />
              <ZAxis dataKey="revenue" range={[40, 400]} />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    labelKey="name"
                    formatter={(value, name) => {
                      if (name === "avgPrice") return `$${Number(value).toFixed(2)}`
                      if (name === "revenue") return `$${Number(value).toLocaleString()}`
                      return String(value)
                    }}
                  />
                }
              />
              <Scatter
                data={scatterData}
                fill="var(--color-chart-2)"
                fillOpacity={0.6}
              />
            </ScatterChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Pricing recommendations table */}
      <Card>
        <CardHeader>
          <CardTitle>Pricing Recommendations</CardTitle>
          <CardDescription>
            Data-driven suggestions based on demand, volume, and price analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Avg Price</TableHead>
                  <TableHead>Units Sold</TableHead>
                  <TableHead>Demand</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead className="min-w-[200px]">Reasoning</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {insights.map((insight) => (
                  <TableRow key={insight.item}>
                    <TableCell className="font-medium">
                      {insight.item}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {insight.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono">
                      ${insight.avgPrice.toFixed(2)}
                    </TableCell>
                    <TableCell className="font-mono">
                      {insight.totalQty.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          insight.demandLevel === "high"
                            ? "default"
                            : insight.demandLevel === "low"
                              ? "destructive"
                              : "secondary"
                        }
                        className="text-xs capitalize"
                      >
                        {insight.demandLevel}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {insight.recommendation === "increase" ? (
                          <ArrowUp className="h-3.5 w-3.5 text-chart-2" />
                        ) : insight.recommendation === "decrease" ? (
                          <ArrowDown className="h-3.5 w-3.5 text-chart-5" />
                        ) : (
                          <Minus className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                        <span
                          className={`text-xs font-medium capitalize ${
                            insight.recommendation === "increase"
                              ? "text-chart-2"
                              : insight.recommendation === "decrease"
                                ? "text-chart-5"
                                : "text-muted-foreground"
                          }`}
                        >
                          {insight.recommendation}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {insight.reason}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
