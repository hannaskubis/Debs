"use client"

import { useMemo, useState } from "react"
import { ArrowUpDown, AlertTriangle } from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import {
  getProductSummaries,
  getCategoryBreakdown,
  getLowPerformers,
} from "@/lib/analytics/product-analytics"

type SortKey = "totalRevenue" | "totalQty" | "avgPrice"

const categoryConfig: ChartConfig = {
  revenue: { label: "Revenue", color: "var(--color-chart-1)" },
  qty: { label: "Units Sold", color: "var(--color-chart-2)" },
}

const TREND_COLORS = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
]

export function ProductsTab({ data }: { data: DashboardData }) {
  const [sortKey, setSortKey] = useState<SortKey>("totalRevenue")
  const [sortAsc, setSortAsc] = useState(false)
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null)

  const products = useMemo(
    () => getProductSummaries(data.squareItems),
    [data.squareItems]
  )
  const categories = useMemo(
    () => getCategoryBreakdown(data.squareItems),
    [data.squareItems]
  )
  const lowPerformers = useMemo(() => getLowPerformers(products), [products])

  const filteredProducts = useMemo(() => {
    let list = categoryFilter
      ? products.filter((p) => p.category === categoryFilter)
      : products
    list = [...list].sort((a, b) => {
      const diff = a[sortKey] - b[sortKey]
      return sortAsc ? diff : -diff
    })
    return list
  }, [products, categoryFilter, sortKey, sortAsc])

  const topTrendProducts = products.slice(0, 5)
  // Build trend data with all months, sorted chronologically
  const allMonthsMap = new Map<string, string>() // sortKey -> label
  for (const p of topTrendProducts) {
    for (const m of p.monthlyTrend) {
      const parsed = new Date(m.month)
      const sortKey = isNaN(parsed.getTime())
        ? m.month
        : `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, "0")}`
      allMonthsMap.set(sortKey, m.month)
    }
  }
  const sortedMonths = Array.from(allMonthsMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, label]) => label)
  const trendData = sortedMonths.map((month) => {
    const row: Record<string, string | number> = { month }
    for (const p of topTrendProducts) {
      const m = p.monthlyTrend.find((t) => t.month === month)
      row[p.item] = m?.qty || 0
    }
    return row
  })

  const trendConfig: ChartConfig = Object.fromEntries(
    topTrendProducts.map((p, i) => [
      p.item,
      { label: p.item, color: TREND_COLORS[i % TREND_COLORS.length] },
    ])
  )

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc)
    else {
      setSortKey(key)
      setSortAsc(false)
    }
  }

  const uniqueCategories = Array.from(
    new Set(products.map((p) => p.category))
  )

  return (
    <div className="flex flex-col gap-6">
      {/* Category filter */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant={categoryFilter === null ? "default" : "outline"}
          size="sm"
          onClick={() => setCategoryFilter(null)}
        >
          All Categories
        </Button>
        {uniqueCategories.map((cat) => (
          <Button
            key={cat}
            variant={categoryFilter === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setCategoryFilter(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* Category breakdown bar chart */}
      <Card>
        <CardHeader>
          <CardTitle>Category Breakdown</CardTitle>
          <CardDescription>Revenue and units by category</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={categoryConfig} className="h-[250px] w-full">
            <BarChart data={categories}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="category" tickLine={false} axisLine={false} />
              <YAxis
                yAxisId="rev"
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <YAxis
                yAxisId="qty"
                orientation="right"
                tickLine={false}
                axisLine={false}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar
                yAxisId="rev"
                dataKey="revenue"
                fill="var(--color-chart-1)"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                yAxisId="qty"
                dataKey="qty"
                fill="var(--color-chart-2)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Top 5 product trends line chart */}
      <Card>
        <CardHeader>
          <CardTitle>Top Sellers Over Time</CardTitle>
          <CardDescription>
            Monthly units sold for top 5 products
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={trendConfig} className="h-[300px] w-full">
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} />
              <YAxis tickLine={false} axisLine={false} />
              <ChartTooltip content={<ChartTooltipContent />} />
              {topTrendProducts.map((p, i) => (
                <Line
                  key={p.item}
                  type="monotone"
                  dataKey={p.item}
                  stroke={TREND_COLORS[i % TREND_COLORS.length]}
                  strokeWidth={2}
                  dot={false}
                />
              ))}
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Product ranking table */}
      <Card>
        <CardHeader>
          <CardTitle>Product Rankings</CardTitle>
          <CardDescription>
            Click column headers to sort. {filteredProducts.length} products
            shown.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8">#</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>
                    <button
                      className="flex items-center gap-1 hover:text-foreground"
                      onClick={() => handleSort("totalRevenue")}
                    >
                      Revenue
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead>
                    <button
                      className="flex items-center gap-1 hover:text-foreground"
                      onClick={() => handleSort("totalQty")}
                    >
                      Units
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead>
                    <button
                      className="flex items-center gap-1 hover:text-foreground"
                      onClick={() => handleSort("avgPrice")}
                    >
                      Avg Price
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((p, i) => (
                  <TableRow key={p.item}>
                    <TableCell className="text-muted-foreground font-mono text-xs">
                      {i + 1}
                    </TableCell>
                    <TableCell className="font-medium">{p.item}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {p.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono">
                      ${p.totalRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </TableCell>
                    <TableCell className="font-mono">{p.totalQty.toLocaleString()}</TableCell>
                    <TableCell className="font-mono">
                      ${p.avgPrice.toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Low performers */}
      {lowPerformers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-chart-5" />
              Declining Products
            </CardTitle>
            <CardDescription>
              Products with 30%+ decline in recent sales. Consider adjusting
              pricing or discontinuing.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Total Revenue</TableHead>
                    <TableHead>Avg Price</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {lowPerformers.map((p) => (
                    <TableRow key={p.item}>
                      <TableCell className="font-medium">{p.item}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {p.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono">
                        ${p.totalRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </TableCell>
                      <TableCell className="font-mono">
                        ${p.avgPrice.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
