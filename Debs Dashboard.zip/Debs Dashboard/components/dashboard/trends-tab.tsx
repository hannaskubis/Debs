"use client"

import { useMemo } from "react"
import {
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import { getMonthlySummaries } from "@/lib/analytics/financial-analytics"

const revenueConfig: ChartConfig = {
  revenue: { label: "Revenue", color: "var(--color-chart-2)" },
}

const netFlowConfig: ChartConfig = {
  netFlow: { label: "Net Cash Flow", color: "var(--color-chart-1)" },
}

export function TrendsTab({ data }: { data: DashboardData }) {
  const monthlies = useMemo(
    () => getMonthlySummaries(data.bankTransactions, data.squareItems),
    [data.bankTransactions, data.squareItems]
  )

  // Month-over-month growth rates
  const growthData: Array<{
    month: string
    label: string
    revenue: number
    expenses: number
    netFlow: number
    deposits: number
    depositCount: number
    revenueGrowth: number
    expenseGrowth: number
  }> = useMemo(() => {
    return monthlies.map((m, i) => {
      if (i === 0)
        return { ...m, revenueGrowth: 0, expenseGrowth: 0 }
      const prev = monthlies[i - 1]
      return {
        ...m,
        revenueGrowth:
          prev.revenue > 0
            ? ((m.revenue - prev.revenue) / prev.revenue) * 100
            : 0,
        expenseGrowth:
          prev.expenses > 0
            ? ((m.expenses - prev.expenses) / prev.expenses) * 100
            : 0,
      }
    })
  }, [monthlies])

  // Moving average (3-month)
  const movingAvgData = useMemo(() => {
    return monthlies.map((m, i) => {
      const window = monthlies.slice(Math.max(0, i - 2), i + 1)
      const avgRevenue =
        window.reduce((s, w) => s + w.revenue, 0) / window.length
      return {
        ...m,
        movingAvg: Math.round(avgRevenue),
      }
    })
  }, [monthlies])

  // Compute some summary stats
  const avgRevenue =
    monthlies.length > 0
      ? monthlies.reduce((s, m) => s + m.revenue, 0) / monthlies.length
      : 0
  const avgExpenses =
    monthlies.length > 0
      ? monthlies.reduce((s, m) => s + m.expenses, 0) / monthlies.length
      : 0
  const latestGrowth = growthData.length > 1 ? growthData[growthData.length - 1] : null

  return (
    <div className="flex flex-col gap-6">
      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Avg Monthly Revenue</CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              ${avgRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Avg Monthly Expenses</CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              ${avgExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Latest Month Growth</CardDescription>
            <CardTitle className="flex items-center gap-2 text-2xl font-mono tabular-nums">
              {latestGrowth ? (
                <>
                  {latestGrowth.revenueGrowth > 0 ? (
                    <ArrowUpRight className="h-5 w-5 text-chart-2" />
                  ) : latestGrowth.revenueGrowth < 0 ? (
                    <ArrowDownRight className="h-5 w-5 text-destructive" />
                  ) : (
                    <Minus className="h-5 w-5 text-muted-foreground" />
                  )}
                  {latestGrowth.revenueGrowth.toFixed(1)}%
                </>
              ) : (
                "N/A"
              )}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Revenue trend with moving average */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue Trend</CardTitle>
          <CardDescription>
            Monthly revenue with 3-month moving average
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={revenueConfig} className="h-[320px] w-full">
            <AreaChart data={movingAvgData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tickLine={false} axisLine={false} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="var(--color-chart-2)"
                fill="var(--color-chart-2)"
                fillOpacity={0.15}
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="movingAvg"
                stroke="var(--color-chart-3)"
                fill="none"
                strokeWidth={2}
                strokeDasharray="5 5"
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Net cash flow bar chart */}
      <Card>
        <CardHeader>
          <CardTitle>Net Cash Flow</CardTitle>
          <CardDescription>
            Monthly deposits minus expenses (bank data)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={netFlowConfig} className="h-[280px] w-full">
            <BarChart data={monthlies}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tickLine={false} axisLine={false} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) =>
                  `${v < 0 ? "-" : ""}$${Math.abs(v / 1000).toFixed(0)}k`
                }
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              <Bar
                dataKey="netFlow"
                radius={[4, 4, 0, 0]}
                fill="var(--color-chart-1)"
              />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Month-over-month growth */}
      <Card>
        <CardHeader>
          <CardTitle>Month-over-Month Growth</CardTitle>
          <CardDescription>
            Revenue and expense growth rate changes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3">
            {growthData.slice(1).map((g) => (
              <div
                key={g.month}
                className="flex items-center justify-between rounded-md border px-4 py-3"
              >
                <span className="text-sm font-medium text-foreground">
                  {g.label}
                </span>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-1 text-sm">
                    <span className="text-muted-foreground">Revenue:</span>
                    <span
                      className={`font-mono font-medium ${
                        g.revenueGrowth >= 0
                          ? "text-chart-2"
                          : "text-destructive"
                      }`}
                    >
                      {g.revenueGrowth >= 0 ? "+" : ""}
                      {g.revenueGrowth.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-sm">
                    <span className="text-muted-foreground">Expenses:</span>
                    <span
                      className={`font-mono font-medium ${
                        g.expenseGrowth <= 0
                          ? "text-chart-2"
                          : "text-destructive"
                      }`}
                    >
                      {g.expenseGrowth >= 0 ? "+" : ""}
                      {g.expenseGrowth.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
