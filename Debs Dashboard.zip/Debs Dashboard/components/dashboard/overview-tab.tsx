"use client"

import { useMemo } from "react"
import {
  DollarSign,
  TrendingDown,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
} from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import { getKPIs, getMonthlySummaries } from "@/lib/analytics/financial-analytics"
import {
  getProductSummaries,
  getCategoryBreakdown,
} from "@/lib/analytics/product-analytics"

const revenueExpenseConfig: ChartConfig = {
  revenue: { label: "Revenue", color: "var(--color-chart-2)" },
  expenses: { label: "Expenses", color: "var(--color-chart-5)" },
}

const topProductsConfig: ChartConfig = {
  revenue: { label: "Revenue", color: "var(--color-chart-1)" },
}

const PIE_COLORS = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
]

export function OverviewTab({ data }: { data: DashboardData }) {
  const kpis = useMemo(
    () => getKPIs(data.bankTransactions, data.squareItems),
    [data.bankTransactions, data.squareItems]
  )
  const monthlies = useMemo(
    () => getMonthlySummaries(data.bankTransactions, data.squareItems),
    [data.bankTransactions, data.squareItems]
  )
  const products = useMemo(
    () => getProductSummaries(data.squareItems),
    [data.squareItems]
  )
  const categories = useMemo(
    () => getCategoryBreakdown(data.squareItems),
    [data.squareItems]
  )

  const topProducts = products.slice(0, 5)

  const kpiCards = [
    {
      title: "Total Revenue",
      value: kpis.totalRevenue,
      change: kpis.revenueGrowth,
      icon: DollarSign,
      prefix: "$",
    },
    {
      title: "Total Expenses",
      value: kpis.totalExpenses,
      change: kpis.expenseGrowth,
      icon: TrendingDown,
      prefix: "$",
      invertChange: true,
    },
    {
      title: "Net Cash Flow",
      value: kpis.netCashFlow,
      change: null,
      icon: kpis.netCashFlow >= 0 ? TrendingUp : TrendingDown,
      prefix: "$",
    },
    {
      title: "Transactions",
      value: kpis.totalTransactions,
      change: null,
      icon: Activity,
      prefix: "",
    },
  ]

  const categoryPieConfig: ChartConfig = Object.fromEntries(
    categories.map((c, i) => [
      c.category,
      { label: c.category, color: PIE_COLORS[i % PIE_COLORS.length] },
    ])
  )

  return (
    <div className="flex flex-col gap-6">
      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpiCards.map((kpi) => (
          <Card key={kpi.title}>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center justify-between">
                {kpi.title}
                <kpi.icon className="h-4 w-4 text-muted-foreground" />
              </CardDescription>
              <CardTitle className="text-2xl font-bold font-mono tabular-nums">
                {kpi.prefix}
                {Math.abs(kpi.value).toLocaleString(undefined, {
                  minimumFractionDigits: kpi.prefix === "$" ? 0 : 0,
                  maximumFractionDigits: kpi.prefix === "$" ? 0 : 0,
                })}
              </CardTitle>
            </CardHeader>
            {kpi.change !== null && (
              <CardContent>
                <div
                  className={`flex items-center gap-1 text-xs ${
                    (kpi.invertChange ? -kpi.change : kpi.change) >= 0
                      ? "text-chart-2"
                      : "text-destructive"
                  }`}
                >
                  {kpi.change >= 0 ? (
                    <ArrowUpRight className="h-3 w-3" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3" />
                  )}
                  {Math.abs(kpi.change).toFixed(1)}% from last month
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {/* Revenue vs Expenses area chart */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue vs Expenses</CardTitle>
          <CardDescription>Monthly comparison over time</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={revenueExpenseConfig} className="h-[300px] w-full">
            <AreaChart data={monthlies}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tickLine={false} axisLine={false} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="var(--color-chart-2)"
                fill="var(--color-chart-2)"
                fillOpacity={0.15}
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="expenses"
                stroke="var(--color-chart-5)"
                fill="var(--color-chart-5)"
                fillOpacity={0.1}
                strokeWidth={2}
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Top products + Category split */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top 5 Products</CardTitle>
            <CardDescription>By total revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={topProductsConfig} className="h-[280px] w-full">
              <BarChart
                data={topProducts}
                layout="vertical"
                margin={{ left: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis
                  type="number"
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                />
                <YAxis
                  dataKey="item"
                  type="category"
                  tickLine={false}
                  axisLine={false}
                  width={110}
                  className="text-xs"
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value) =>
                        `$${Number(value).toLocaleString()}`
                      }
                    />
                  }
                />
                <Bar
                  dataKey="totalRevenue"
                  name="revenue"
                  fill="var(--color-chart-1)"
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Category Split</CardTitle>
            <CardDescription>Revenue by product category</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={categoryPieConfig} className="h-[280px] w-full">
              <PieChart>
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value) =>
                        `$${Number(value).toLocaleString()}`
                      }
                    />
                  }
                />
                <Pie
                  data={categories}
                  dataKey="revenue"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                >
                  {categories.map((_, i) => (
                    <Cell
                      key={i}
                      fill={PIE_COLORS[i % PIE_COLORS.length]}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
            <div className="mt-4 flex flex-wrap justify-center gap-4">
              {categories.map((cat, i) => (
                <div key={cat.category} className="flex items-center gap-2 text-xs">
                  <div
                    className="h-2.5 w-2.5 rounded-sm"
                    style={{
                      backgroundColor: PIE_COLORS[i % PIE_COLORS.length],
                    }}
                  />
                  <span className="text-muted-foreground">{cat.category}</span>
                  <span className="font-mono font-medium text-foreground">
                    {cat.percentage.toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
