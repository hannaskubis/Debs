"use client"

import { useMemo } from "react"
import { CalendarDays, Clock, DollarSign, Target } from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ScatterChart,
  Scatter,
  ZAxis,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import {
  getDepositAnalysis,
  getDepositStats,
  getDepositFrequency,
} from "@/lib/analytics/deposit-analytics"

const frequencyConfig: ChartConfig = {
  count: { label: "Deposits", color: "var(--color-chart-1)" },
  total: { label: "Total Amount", color: "var(--color-chart-2)" },
}

const scatterConfig: ChartConfig = {
  deposits: { label: "Deposit", color: "var(--color-chart-1)" },
}

export function DepositsTab({ data }: { data: DashboardData }) {
  const deposits = useMemo(
    () => getDepositAnalysis(data.bankTransactions),
    [data.bankTransactions]
  )
  const stats = useMemo(() => getDepositStats(deposits), [deposits])
  const frequency = useMemo(
    () => getDepositFrequency(deposits),
    [deposits]
  )

  const scatterData = useMemo(
    () =>
      deposits.map((d) => ({
        date: d.date.toLocaleDateString(),
        amount: d.amount,
        gap: d.daysSinceLast ?? 0,
      })),
    [deposits]
  )

  return (
    <div className="flex flex-col gap-6">
      {/* KPI row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center justify-between">
              Total Deposits
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
            </CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              {stats.totalDeposits}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center justify-between">
              Avg Days Between
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              {stats.avgDaysBetween} days
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center justify-between">
              Avg Deposit Amount
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              ${stats.avgAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center justify-between">
              Consistency Score
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardDescription>
            <CardTitle className="text-2xl font-mono tabular-nums">
              {stats.consistencyScore}/100
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={stats.consistencyScore} className="h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Deposit frequency chart */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Deposit Activity</CardTitle>
          <CardDescription>
            Number of deposits and total amounts by month
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={frequencyConfig} className="h-[300px] w-full">
            <BarChart data={frequency}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} />
              <YAxis
                yAxisId="count"
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                yAxisId="total"
                orientation="right"
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar
                yAxisId="count"
                dataKey="count"
                fill="var(--color-chart-1)"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                yAxisId="total"
                dataKey="total"
                fill="var(--color-chart-2)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Deposit scatter / timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Deposit Timeline</CardTitle>
          <CardDescription>
            Each point represents a deposit. Size reflects the amount, Y-axis
            shows days since the previous deposit.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={scatterConfig} className="h-[300px] w-full">
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false}
                type="category"
                interval="preserveStartEnd"
              />
              <YAxis
                dataKey="gap"
                tickLine={false}
                axisLine={false}
                name="Days gap"
                label={{
                  value: "Days gap",
                  angle: -90,
                  position: "insideLeft",
                  style: { textAnchor: "middle", fontSize: 12 },
                }}
              />
              <ZAxis dataKey="amount" range={[40, 400]} />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value, name) =>
                      name === "gap"
                        ? `${value} days`
                        : `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              <Scatter
                data={scatterData}
                fill="var(--color-chart-1)"
                fillOpacity={0.6}
              />
            </ScatterChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>Deposit Cadence Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3">
            {stats.avgDaysBetween > 10 && (
              <div className="rounded-md border border-chart-5/30 bg-chart-5/5 px-4 py-3">
                <p className="text-sm font-medium text-foreground">
                  Consider more frequent deposits
                </p>
                <p className="text-xs text-muted-foreground">
                  Your average gap is {stats.avgDaysBetween} days. Depositing
                  weekly could improve cash flow predictability and reduce risk
                  of loss.
                </p>
              </div>
            )}
            {stats.maxGap > 20 && (
              <div className="rounded-md border border-chart-5/30 bg-chart-5/5 px-4 py-3">
                <p className="text-sm font-medium text-foreground">
                  Watch for long gaps
                </p>
                <p className="text-xs text-muted-foreground">
                  Your longest gap between deposits was {stats.maxGap} days.
                  Large gaps can indicate cash handling issues or missed
                  deposits.
                </p>
              </div>
            )}
            {stats.consistencyScore >= 70 && (
              <div className="rounded-md border border-chart-2/30 bg-chart-2/5 px-4 py-3">
                <p className="text-sm font-medium text-foreground">
                  Good consistency
                </p>
                <p className="text-xs text-muted-foreground">
                  Your deposit schedule is fairly consistent with a score of{" "}
                  {stats.consistencyScore}/100. Keep it up!
                </p>
              </div>
            )}
            {stats.consistencyScore < 70 && (
              <div className="rounded-md border border-chart-5/30 bg-chart-5/5 px-4 py-3">
                <p className="text-sm font-medium text-foreground">
                  Improve deposit regularity
                </p>
                <p className="text-xs text-muted-foreground">
                  Your consistency score is {stats.consistencyScore}/100.
                  Setting a fixed deposit day each week can help improve
                  predictability.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
