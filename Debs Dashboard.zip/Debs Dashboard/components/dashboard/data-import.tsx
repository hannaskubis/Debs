"use client"

import { useState, useCallback, useRef } from "react"
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Database,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import {
  parseBankFile,
  detectBankColumns,
  parseBankData,
} from "@/lib/parsers/bank-parser"
import {
  parseSquareFile,
  detectSquareColumns,
  parseSquareData,
} from "@/lib/parsers/square-parser"
import {
  generateSampleBankData,
  generateSampleSquareData,
} from "@/lib/sample-data"
import type { DashboardData, ColumnMapping } from "@/lib/types"

interface DataImportProps {
  onDataLoaded: (data: Partial<DashboardData>) => void
  onClearData: () => void
  hasData: boolean
}

type ImportStep = "upload" | "mapping" | "done"
type FileType = "bank" | "square"

interface FileState {
  file: File | null
  headers: string[]
  rows: Record<string, unknown>[]
  mapping: ColumnMapping
  step: ImportStep
  recordCount: number
  error: string | null
}

const initialFileState: FileState = {
  file: null,
  headers: [],
  rows: [],
  mapping: {},
  step: "upload",
  recordCount: 0,
  error: null,
}

export function DataImport({
  onDataLoaded,
  onClearData,
  hasData,
}: DataImportProps) {
  const [bankState, setBankState] = useState<FileState>(initialFileState)
  const [squareState, setSquareState] = useState<FileState>(initialFileState)
  const bankRef = useRef<HTMLInputElement>(null)
  const squareRef = useRef<HTMLInputElement>(null)

  const handleFilePick = useCallback(
    async (file: File, type: FileType) => {
      const setState = type === "bank" ? setBankState : setSquareState
      try {
        const { headers, rows } =
          type === "bank"
            ? await parseBankFile(file)
            : await parseSquareFile(file)

        const mapping =
          type === "bank"
            ? detectBankColumns(headers)
            : detectSquareColumns(headers)

        setState({
          file,
          headers,
          rows,
          mapping,
          step: "mapping",
          recordCount: rows.length,
          error: null,
        })
      } catch {
        setState({
          ...initialFileState,
          error: "Failed to parse file. Please check the format and try again.",
        })
      }
    },
    []
  )

  const handleConfirmMapping = useCallback(
    (type: FileType) => {
      const state = type === "bank" ? bankState : squareState
      const setState = type === "bank" ? setBankState : setSquareState

      try {
        if (type === "bank") {
          const transactions = parseBankData(state.rows, state.mapping)
          onDataLoaded({ bankTransactions: transactions })
          setState((prev) => ({
            ...prev,
            step: "done",
            recordCount: transactions.length,
          }))
        } else {
          const items = parseSquareData(state.rows, state.mapping)
          onDataLoaded({ squareItems: items })
          setState((prev) => ({
            ...prev,
            step: "done",
            recordCount: items.length,
          }))
        }
      } catch {
        setState((prev) => ({
          ...prev,
          error: "Failed to process data. Please check column mapping.",
        }))
      }
    },
    [bankState, squareState, onDataLoaded]
  )

  const handleLoadDemo = useCallback(() => {
    const bankTransactions = generateSampleBankData()
    const squareItems = generateSampleSquareData()
    onDataLoaded({ bankTransactions, squareItems })
    setBankState((prev) => ({
      ...prev,
      step: "done",
      recordCount: bankTransactions.length,
    }))
    setSquareState((prev) => ({
      ...prev,
      step: "done",
      recordCount: squareItems.length,
    }))
  }, [onDataLoaded])

  const handleClear = useCallback(() => {
    setBankState(initialFileState)
    setSquareState(initialFileState)
    onClearData()
  }, [onClearData])

  return (
    <div className="flex flex-col gap-6">
      {/* Demo data prompt */}
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center gap-4 py-8 sm:flex-row sm:justify-between">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <Database className="h-8 w-8 text-muted-foreground shrink-0" />
            <div>
              <p className="font-medium text-foreground">
                Try it out with sample data
              </p>
              <p className="text-sm text-muted-foreground">
                Load 12 months of realistic demo data to explore all dashboard
                features.
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleLoadDemo} variant="default">
              Load Demo Data
            </Button>
            {hasData && (
              <Button onClick={handleClear} variant="outline" size="icon">
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Clear all data</span>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload cards */}
      <div className="grid gap-6 md:grid-cols-2">
        <FileUploadCard
          title="Bank Account Data"
          description="Upload your bank CSV or Excel export (Date, Description, Amount, Balance)"
          type="bank"
          state={bankState}
          inputRef={bankRef}
          onFilePick={handleFilePick}
          onConfirm={handleConfirmMapping}
        />
        <FileUploadCard
          title="Square Sales Data"
          description="Upload your Square Items Detail CSV or Excel export"
          type="square"
          state={squareState}
          inputRef={squareRef}
          onFilePick={handleFilePick}
          onConfirm={handleConfirmMapping}
        />
      </div>
    </div>
  )
}

function FileUploadCard({
  title,
  description,
  type,
  state,
  inputRef,
  onFilePick,
  onConfirm,
}: {
  title: string
  description: string
  type: FileType
  state: FileState
  inputRef: React.RefObject<HTMLInputElement | null>
  onFilePick: (file: File, type: FileType) => void
  onConfirm: (type: FileType) => void
}) {
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      const file = e.dataTransfer.files[0]
      if (file) onFilePick(file, type)
    },
    [onFilePick, type]
  )

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) onFilePick(file, type)
    },
    [onFilePick, type]
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
          {title}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {state.error && (
          <div className="mb-4 flex items-center gap-2 rounded-md bg-destructive/10 p-3 text-sm text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" />
            {state.error}
          </div>
        )}

        {state.step === "upload" && (
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => inputRef.current?.click()}
            className="flex cursor-pointer flex-col items-center gap-3 rounded-lg border-2 border-dashed border-muted-foreground/25 p-8 text-center transition-colors hover:border-muted-foreground/50 hover:bg-muted/50"
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") inputRef.current?.click()
            }}
          >
            <Upload className="h-8 w-8 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium text-foreground">
                Drop file here or click to browse
              </p>
              <p className="text-xs text-muted-foreground">
                CSV, XLS, or XLSX files supported
              </p>
            </div>
            <input
              ref={inputRef}
              type="file"
              accept=".csv,.xls,.xlsx"
              onChange={handleChange}
              className="hidden"
              aria-label={`Upload ${title}`}
            />
          </div>
        )}

        {state.step === "mapping" && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <Badge variant="secondary">
                {state.recordCount} rows detected
              </Badge>
              <span className="text-xs text-muted-foreground">
                {state.file?.name}
              </span>
            </div>

            {/* Column mapping preview */}
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Field</TableHead>
                    <TableHead>Mapped Column</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(state.mapping).map(([field, col]) => (
                    <TableRow key={field}>
                      <TableCell className="font-medium capitalize">
                        {field}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{col}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Preview first few rows */}
            {state.rows.length > 0 && (
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {state.headers.slice(0, 6).map((h) => (
                        <TableHead key={h} className="text-xs">
                          {h}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {state.rows.slice(0, 3).map((row, i) => (
                      <TableRow key={i}>
                        {state.headers.slice(0, 6).map((h) => (
                          <TableCell key={h} className="text-xs">
                            {String(row[h] ?? "")}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            <Button onClick={() => onConfirm(type)} className="w-full">
              Confirm & Import
            </Button>
          </div>
        )}

        {state.step === "done" && (
          <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-4">
            <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0" />
            <div>
              <p className="text-sm font-medium text-foreground">
                {state.recordCount} records imported
              </p>
              <p className="text-xs text-muted-foreground">
                {state.file?.name || "Demo data loaded"}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
