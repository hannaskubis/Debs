"use client"

import { useState, useCallback } from "react"
import {
  BarChart3,
  Upload,
  TrendingUp,
  PiggyBank,
  ShoppingBag,
  DollarSign,
  LayoutDashboard,
  Banknote,
} from "lucide-react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { DataImport } from "@/components/dashboard/data-import"
import { OverviewTab } from "@/components/dashboard/overview-tab"
import { ProductsTab } from "@/components/dashboard/products-tab"
import { TrendsTab } from "@/components/dashboard/trends-tab"
import { DepositsTab } from "@/components/dashboard/deposits-tab"
import { SpendingTab } from "@/components/dashboard/spending-tab"
import { PricingTab } from "@/components/dashboard/pricing-tab"
import type { DashboardData } from "@/lib/types"

export function DashboardShell() {
  const [data, setData] = useState<DashboardData>({
    bankTransactions: [],
    squareItems: [],
    dateRange: null,
  })
  const [activeTab, setActiveTab] = useState("import")

  const hasData =
    data.bankTransactions.length > 0 || data.squareItems.length > 0

  const handleDataLoaded = useCallback(
    (newData: Partial<DashboardData>) => {
      setData((prev) => {
        const merged = { ...prev, ...newData }
        // Compute date range
        const allDates = [
          ...merged.bankTransactions.map((t) => t.date),
          ...merged.squareItems.map((s) => s.date),
        ]
        if (allDates.length > 0) {
          merged.dateRange = {
            start: new Date(Math.min(...allDates.map((d) => d.getTime()))),
            end: new Date(Math.max(...allDates.map((d) => d.getTime()))),
          }
        }
        return merged
      })
      setActiveTab("overview")
    },
    []
  )

  const handleClearData = useCallback(() => {
    setData({ bankTransactions: [], squareItems: [], dateRange: null })
    setActiveTab("import")
  }, [])

  const navItems = [
    { value: "import", label: "Import", icon: Upload },
    { value: "overview", label: "Overview", icon: LayoutDashboard },
    { value: "products", label: "Products", icon: ShoppingBag },
    { value: "trends", label: "Trends", icon: TrendingUp },
    { value: "deposits", label: "Deposits", icon: Banknote },
    { value: "spending", label: "Spending", icon: PiggyBank },
    { value: "pricing", label: "Pricing", icon: DollarSign },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <BarChart3 className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground leading-none">
                Club Dashboard
              </h1>
              <p className="text-xs text-muted-foreground">
                Financial Analytics
              </p>
            </div>
          </div>
          {data.dateRange && (
            <div className="ml-auto text-xs text-muted-foreground">
              {data.dateRange.start.toLocaleDateString()} -{" "}
              {data.dateRange.end.toLocaleDateString()}
            </div>
          )}
        </div>
      </header>

      {/* Main content with tabs */}
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="mx-auto max-w-7xl px-4 py-6 sm:px-6"
      >
        <TabsList className="mb-6 flex w-full flex-wrap gap-1 h-auto bg-muted/50 p-1">
          {navItems.map(({ value, label, icon: Icon }) => (
            <TabsTrigger
              key={value}
              value={value}
              disabled={value !== "import" && !hasData}
              className="gap-1.5 text-xs sm:text-sm"
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{label}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="import">
          <DataImport onDataLoaded={handleDataLoaded} onClearData={handleClearData} hasData={hasData} />
        </TabsContent>
        <TabsContent value="overview">
          <OverviewTab data={data} />
        </TabsContent>
        <TabsContent value="products">
          <ProductsTab data={data} />
        </TabsContent>
        <TabsContent value="trends">
          <TrendsTab data={data} />
        </TabsContent>
        <TabsContent value="deposits">
          <DepositsTab data={data} />
        </TabsContent>
        <TabsContent value="spending">
          <SpendingTab data={data} />
        </TabsContent>
        <TabsContent value="pricing">
          <PricingTab data={data} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
