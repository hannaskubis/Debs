"use client"

import { useMemo, useState } from "react"
import {
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Search,
} from "lucide-react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card"
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts"
import type { DashboardData } from "@/lib/types"
import {
  getSpendingByCategory,
  getSpendingRecommendations,
  categorizeExpense,
} from "@/lib/analytics/spending-analytics"

const spendingConfig: ChartConfig = {
  total: { label: "Total", color: "var(--color-chart-5)" },
}

const TREND_COLORS = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
]

export function SpendingTab({ data }: { data: DashboardData }) {
  const [searchTerm, setSearchTerm] = useState("")

  const categories = useMemo(
    () => getSpendingByCategory(data.bankTransactions),
    [data.bankTransactions]
  )
  const recommendations = useMemo(
    () => getSpendingRecommendations(categories),
    [categories]
  )

  const expenses = useMemo(
    () =>
      data.bankTransactions
        .filter((tx) => tx.amount < 0)
        .sort((a, b) => b.date.getTime() - a.date.getTime()),
    [data.bankTransactions]
  )

  const filteredExpenses = useMemo(() => {
    if (!searchTerm) return expenses.slice(0, 50)
    const term = searchTerm.toLowerCase()
    return expenses
      .filter((tx) => tx.description.toLowerCase().includes(term))
      .slice(0, 50)
  }, [expenses, searchTerm])

  // Build spending trend data, sorted chronologically
  const allMonthsMap = new Map<string, string>()
  for (const cat of categories.slice(0, 5)) {
    for (const m of cat.monthlyAmounts) {
      const parsed = new Date(m.month)
      const sortKey = isNaN(parsed.getTime())
        ? m.month
        : `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, "0")}`
      allMonthsMap.set(sortKey, m.month)
    }
  }
  const sortedMonths = Array.from(allMonthsMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, label]) => label)
  const trendData = sortedMonths.map((month) => {
    const row: Record<string, string | number> = { month }
    for (const cat of categories.slice(0, 5)) {
      const m = cat.monthlyAmounts.find((a) => a.month === month)
      row[cat.category] = m ? Math.round(m.amount) : 0
    }
    return row
  })

  const trendConfig: ChartConfig = Object.fromEntries(
    categories.slice(0, 5).map((c, i) => [
      c.category,
      { label: c.category, color: TREND_COLORS[i % TREND_COLORS.length] },
    ])
  )

  const totalSpending = categories.reduce((s, c) => s + c.total, 0)

  return (
    <div className="flex flex-col gap-6">
      {/* Recommendations */}
      {recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Spending Insights</CardTitle>
            <CardDescription>
              Auto-detected patterns and recommendations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {recommendations.map((rec, i) => (
                <div
                  key={i}
                  className={`rounded-md border px-4 py-3 ${
                    rec.severity === "warning"
                      ? "border-chart-5/30 bg-chart-5/5"
                      : rec.severity === "success"
                        ? "border-chart-2/30 bg-chart-2/5"
                        : "border-border bg-muted/30"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        rec.severity === "warning" ? "destructive" : "secondary"
                      }
                      className="text-xs"
                    >
                      {rec.category}
                    </Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {rec.message}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Spending by category */}
      <Card>
        <CardHeader>
          <CardTitle>Spending by Category</CardTitle>
          <CardDescription>
            Total: ${totalSpending.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={spendingConfig} className="h-[300px] w-full">
            <BarChart data={categories} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis
                type="number"
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <YAxis
                dataKey="category"
                type="category"
                tickLine={false}
                axisLine={false}
                width={140}
                className="text-xs"
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              <Bar
                dataKey="total"
                fill="var(--color-chart-5)"
                radius={[0, 4, 4, 0]}
              />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Spending trends over time */}
      <Card>
        <CardHeader>
          <CardTitle>Spending Trends</CardTitle>
          <CardDescription>
            Top 5 spending categories over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={trendConfig} className="h-[300px] w-full">
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(1)}k`}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      `$${Number(value).toLocaleString()}`
                    }
                  />
                }
              />
              {categories.slice(0, 5).map((cat, i) => (
                <Line
                  key={cat.category}
                  type="monotone"
                  dataKey={cat.category}
                  stroke={TREND_COLORS[i % TREND_COLORS.length]}
                  strokeWidth={2}
                  dot={false}
                />
              ))}
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Category detail table */}
      <Card>
        <CardHeader>
          <CardTitle>Category Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Transactions</TableHead>
                  <TableHead>Avg Amount</TableHead>
                  <TableHead>Trend</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((cat) => (
                  <TableRow key={cat.category}>
                    <TableCell className="font-medium">
                      {cat.category}
                    </TableCell>
                    <TableCell className="font-mono">
                      ${cat.total.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </TableCell>
                    <TableCell className="font-mono">{cat.count}</TableCell>
                    <TableCell className="font-mono">
                      ${cat.avgAmount.toFixed(0)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {cat.trend === "rising" ? (
                          <ArrowUpRight className="h-3.5 w-3.5 text-destructive" />
                        ) : cat.trend === "falling" ? (
                          <ArrowDownRight className="h-3.5 w-3.5 text-chart-2" />
                        ) : (
                          <Minus className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                        <span
                          className={`text-xs capitalize ${
                            cat.trend === "rising"
                              ? "text-destructive"
                              : cat.trend === "falling"
                                ? "text-chart-2"
                                : "text-muted-foreground"
                          }`}
                        >
                          {cat.trend}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* All expenses table */}
      <Card>
        <CardHeader>
          <CardTitle>All Expenses</CardTitle>
          <CardDescription>
            Showing {filteredExpenses.length} of {expenses.length} expense
            transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredExpenses.map((tx, i) => (
                  <TableRow key={i}>
                    <TableCell className="text-xs text-muted-foreground font-mono">
                      {tx.date.toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-sm">{tx.description}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {categorizeExpense(tx.description)}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-destructive">
                      -${Math.abs(tx.amount).toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
