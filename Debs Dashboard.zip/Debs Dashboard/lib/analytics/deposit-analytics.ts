import { differenceInDays, format } from "date-fns"
import type { BankTransaction, DepositAnalysis } from "@/lib/types"

export function getDepositAnalysis(
  transactions: BankTransaction[]
): DepositAnalysis[] {
  const deposits = transactions
    .filter((tx) => tx.amount > 0)
    .sort((a, b) => a.date.getTime() - b.date.getTime())

  return deposits.map((dep, i) => ({
    date: dep.date,
    amount: dep.amount,
    daysSinceLast:
      i > 0 ? differenceInDays(dep.date, deposits[i - 1].date) : null,
  }))
}

export function getDepositStats(deposits: DepositAnalysis[]) {
  const gaps = deposits
    .map((d) => d.daysSinceLast)
    .filter((d): d is number => d !== null)

  const avgDaysBetween =
    gaps.length > 0 ? gaps.reduce((s, g) => s + g, 0) / gaps.length : 0

  const avgAmount =
    deposits.length > 0
      ? deposits.reduce((s, d) => s + d.amount, 0) / deposits.length
      : 0

  const maxGap = gaps.length > 0 ? Math.max(...gaps) : 0
  const minGap = gaps.length > 0 ? Math.min(...gaps) : 0

  // Consistency score: lower std deviation of gaps = more consistent
  const mean = avgDaysBetween
  const variance =
    gaps.length > 0
      ? gaps.reduce((s, g) => s + Math.pow(g - mean, 2), 0) / gaps.length
      : 0
  const stdDev = Math.sqrt(variance)
  const consistencyScore = Math.max(0, Math.min(100, 100 - stdDev * 5))

  return {
    totalDeposits: deposits.length,
    avgDaysBetween: Math.round(avgDaysBetween * 10) / 10,
    avgAmount,
    maxGap,
    minGap,
    consistencyScore: Math.round(consistencyScore),
  }
}

export function getDepositCalendar(
  deposits: DepositAnalysis[]
): { date: string; amount: number }[] {
  return deposits.map((d) => ({
    date: format(d.date, "yyyy-MM-dd"),
    amount: d.amount,
  }))
}

export function getDepositFrequency(
  deposits: DepositAnalysis[]
): { month: string; count: number; total: number }[] {
  const map = new Map<string, { count: number; total: number }>()

  for (const dep of deposits) {
    const key = format(dep.date, "yyyy-MM")
    if (!map.has(key)) {
      map.set(key, { count: 0, total: 0 })
    }
    const entry = map.get(key)!
    entry.count += 1
    entry.total += dep.amount
  }

  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, data]) => ({
      month: format(new Date(month + "-01"), "MMM yyyy"),
      count: data.count,
      total: data.total,
    }))
}
