import { format } from "date-fns"
import type { SquareItem, ProductSummary, CategoryBreakdown } from "@/lib/types"

export function getProductSummaries(items: SquareItem[]): ProductSummary[] {
  const map = new Map<
    string,
    {
      item: string
      category: string
      totalQty: number
      totalRevenue: number
      monthly: Map<string, { qty: number; revenue: number }>
    }
  >()

  for (const sale of items) {
    const key = sale.item
    if (!map.has(key)) {
      map.set(key, {
        item: sale.item,
        category: sale.category,
        totalQty: 0,
        totalRevenue: 0,
        monthly: new Map(),
      })
    }
    const entry = map.get(key)!
    entry.totalQty += sale.qty
    entry.totalRevenue += sale.netSales

    const month = format(sale.date, "yyyy-MM")
    const monthLabel = format(sale.date, "MMM yyyy")
    if (!entry.monthly.has(month)) {
      entry.monthly.set(month, { qty: 0, revenue: 0 })
    }
    const m = entry.monthly.get(month)!
    m.qty += sale.qty
    m.revenue += sale.netSales

    // Store the label as a side-effect-free way
    entry.monthly.set(month, { ...m })
  }

  return Array.from(map.values())
    .map((e) => ({
      item: e.item,
      category: e.category,
      totalQty: e.totalQty,
      totalRevenue: e.totalRevenue,
      avgPrice: e.totalQty > 0 ? e.totalRevenue / e.totalQty : 0,
      monthlyTrend: Array.from(e.monthly.entries())
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([month, data]) => ({
          month: format(new Date(month + "-01"), "MMM yyyy"),
          qty: data.qty,
          revenue: data.revenue,
        })),
    }))
    .sort((a, b) => b.totalRevenue - a.totalRevenue)
}

export function getCategoryBreakdown(items: SquareItem[]): CategoryBreakdown[] {
  const map = new Map<string, { revenue: number; qty: number }>()
  let totalRevenue = 0

  for (const sale of items) {
    if (!map.has(sale.category)) {
      map.set(sale.category, { revenue: 0, qty: 0 })
    }
    const entry = map.get(sale.category)!
    entry.revenue += sale.netSales
    entry.qty += sale.qty
    totalRevenue += sale.netSales
  }

  return Array.from(map.entries())
    .map(([category, data]) => ({
      category,
      revenue: data.revenue,
      qty: data.qty,
      percentage: totalRevenue > 0 ? (data.revenue / totalRevenue) * 100 : 0,
    }))
    .sort((a, b) => b.revenue - a.revenue)
}

export function getLowPerformers(products: ProductSummary[]): ProductSummary[] {
  return products
    .filter((p) => {
      const trend = p.monthlyTrend
      if (trend.length < 2) return false
      const recent = trend.slice(-2)
      const earlier = trend.slice(0, Math.max(1, trend.length - 2))
      const recentAvg =
        recent.reduce((s, m) => s + m.qty, 0) / recent.length
      const earlierAvg =
        earlier.reduce((s, m) => s + m.qty, 0) / earlier.length
      return recentAvg < earlierAvg * 0.7 // 30%+ decline
    })
    .sort((a, b) => a.totalRevenue - b.totalRevenue)
}
