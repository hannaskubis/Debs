import { format } from "date-fns"
import type { BankTransaction, SpendingCategory } from "@/lib/types"

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  "Square Fees": ["square", "sq *", "squareup"],
  Supplies: [
    "supply",
    "supplies",
    "costco",
    "walmart",
    "sam's club",
    "sams club",
    "amazon",
    "home depot",
    "lowes",
    "office depot",
    "staples",
  ],
  Utilities: [
    "electric",
    "gas",
    "water",
    "utility",
    "power",
    "energy",
    "internet",
    "comcast",
    "att",
    "verizon",
    "t-mobile",
    "spectrum",
  ],
  Rent: ["rent", "lease", "property", "mortgage"],
  Insurance: ["insurance", "insure", "geico", "state farm", "allstate"],
  Subscriptions: [
    "subscription",
    "recurring",
    "monthly",
    "netflix",
    "spotify",
    "adobe",
    "microsoft",
    "google",
    "zoom",
    "slack",
    "quickbooks",
    "intuit",
  ],
  "Food & Beverage Costs": [
    "sysco",
    "food",
    "beverage",
    "restaurant depot",
    "us foods",
    "pepsi",
    "coca-cola",
    "anheuser",
    "liquor",
    "beer",
    "wine",
  ],
  Banking: ["fee", "service charge", "overdraft", "nsf", "maintenance fee"],
  Payroll: ["payroll", "paycheck", "adp", "gusto", "wage"],
}

export function categorizeExpense(description: string): string {
  const lower = description.toLowerCase()
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some((kw) => lower.includes(kw))) {
      return category
    }
  }
  return "Other"
}

export function getSpendingByCategory(
  transactions: BankTransaction[]
): SpendingCategory[] {
  const expenses = transactions.filter((tx) => tx.amount < 0)
  const map = new Map<
    string,
    {
      total: number
      count: number
      monthly: Map<string, number>
    }
  >()

  for (const tx of expenses) {
    const cat = categorizeExpense(tx.description)
    if (!map.has(cat)) {
      map.set(cat, { total: 0, count: 0, monthly: new Map() })
    }
    const entry = map.get(cat)!
    const amt = Math.abs(tx.amount)
    entry.total += amt
    entry.count += 1

    const month = format(tx.date, "yyyy-MM")
    entry.monthly.set(month, (entry.monthly.get(month) || 0) + amt)
  }

  return Array.from(map.entries())
    .map(([category, data]) => {
      const monthlyArr = Array.from(data.monthly.entries())
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([month, amount]) => ({
          month: format(new Date(month + "-01"), "MMM yyyy"),
          amount,
        }))

      // Determine trend
      let trend: "rising" | "falling" | "stable" = "stable"
      if (monthlyArr.length >= 3) {
        const recent = monthlyArr.slice(-2).reduce((s, m) => s + m.amount, 0) / 2
        const earlier =
          monthlyArr
            .slice(0, -2)
            .reduce((s, m) => s + m.amount, 0) /
          Math.max(1, monthlyArr.length - 2)
        if (recent > earlier * 1.15) trend = "rising"
        else if (recent < earlier * 0.85) trend = "falling"
      }

      return {
        category,
        total: data.total,
        count: data.count,
        avgAmount: data.count > 0 ? data.total / data.count : 0,
        trend,
        monthlyAmounts: monthlyArr,
      }
    })
    .sort((a, b) => b.total - a.total)
}

export function getSpendingRecommendations(
  categories: SpendingCategory[]
): { category: string; message: string; severity: "warning" | "info" | "success" }[] {
  const recs: {
    category: string
    message: string
    severity: "warning" | "info" | "success"
  }[] = []

  for (const cat of categories) {
    if (cat.trend === "rising") {
      recs.push({
        category: cat.category,
        message: `${cat.category} spending is trending upward. Review recent charges for potential savings.`,
        severity: "warning",
      })
    }
    if (cat.trend === "falling") {
      recs.push({
        category: cat.category,
        message: `${cat.category} spending has decreased recently. Good cost management.`,
        severity: "success",
      })
    }
    if (cat.category === "Subscriptions" && cat.count > 5) {
      recs.push({
        category: cat.category,
        message: `You have ${cat.count} subscription charges. Consider auditing for unused services.`,
        severity: "warning",
      })
    }
    if (cat.category === "Banking" && cat.total > 100) {
      recs.push({
        category: cat.category,
        message: `$${cat.total.toFixed(0)} in bank fees. Consider switching to a fee-free account.`,
        severity: "warning",
      })
    }
  }

  return recs
}
