import { format } from "date-fns"
import type { BankTransaction, SquareItem, MonthlySummary } from "@/lib/types"

export function getMonthlySummaries(
  bankTransactions: BankTransaction[],
  squareItems: SquareItem[]
): MonthlySummary[] {
  const monthMap = new Map<
    string,
    {
      revenue: number
      expenses: number
      deposits: number
      depositCount: number
    }
  >()

  // Process bank transactions
  for (const tx of bankTransactions) {
    const key = format(tx.date, "yyyy-MM")
    if (!monthMap.has(key)) {
      monthMap.set(key, { revenue: 0, expenses: 0, deposits: 0, depositCount: 0 })
    }
    const entry = monthMap.get(key)!
    if (tx.amount > 0) {
      entry.deposits += tx.amount
      entry.depositCount += 1
    } else {
      entry.expenses += Math.abs(tx.amount)
    }
  }

  // Add Square revenue
  for (const item of squareItems) {
    const key = format(item.date, "yyyy-MM")
    if (!monthMap.has(key)) {
      monthMap.set(key, { revenue: 0, expenses: 0, deposits: 0, depositCount: 0 })
    }
    monthMap.get(key)!.revenue += item.netSales
  }

  return Array.from(monthMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, data]) => ({
      month,
      label: format(new Date(month + "-01"), "MMM yyyy"),
      revenue: data.revenue,
      expenses: data.expenses,
      netFlow: data.deposits - data.expenses,
      deposits: data.deposits,
      depositCount: data.depositCount,
    }))
}

export function getKPIs(
  bankTransactions: BankTransaction[],
  squareItems: SquareItem[]
) {
  const totalRevenue = squareItems.reduce((s, i) => s + i.netSales, 0)
  const totalExpenses = bankTransactions
    .filter((tx) => tx.amount < 0)
    .reduce((s, tx) => s + Math.abs(tx.amount), 0)
  const totalDeposits = bankTransactions
    .filter((tx) => tx.amount > 0)
    .reduce((s, tx) => s + tx.amount, 0)
  const totalTransactions = bankTransactions.length + squareItems.length

  // Month-over-month growth
  const monthlies = getMonthlySummaries(bankTransactions, squareItems)
  let revenueGrowth = 0
  let expenseGrowth = 0
  if (monthlies.length >= 2) {
    const curr = monthlies[monthlies.length - 1]
    const prev = monthlies[monthlies.length - 2]
    revenueGrowth =
      prev.revenue > 0 ? ((curr.revenue - prev.revenue) / prev.revenue) * 100 : 0
    expenseGrowth =
      prev.expenses > 0
        ? ((curr.expenses - prev.expenses) / prev.expenses) * 100
        : 0
  }

  return {
    totalRevenue,
    totalExpenses,
    totalDeposits,
    netCashFlow: totalDeposits - totalExpenses,
    totalTransactions,
    revenueGrowth,
    expenseGrowth,
  }
}
