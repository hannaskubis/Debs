import type { ProductSummary, PricingInsight } from "@/lib/types"

export function getPricingInsights(
  products: ProductSummary[]
): PricingInsight[] {
  if (products.length === 0) return []

  // Calculate category averages
  const categoryMap = new Map<
    string,
    { totalRevenue: number; totalQty: number }
  >()
  for (const p of products) {
    if (!categoryMap.has(p.category)) {
      categoryMap.set(p.category, { totalRevenue: 0, totalQty: 0 })
    }
    const entry = categoryMap.get(p.category)!
    entry.totalRevenue += p.totalRevenue
    entry.totalQty += p.totalQty
  }

  const medianQty = getMedian(products.map((p) => p.totalQty))
  const medianPrice = getMedian(products.map((p) => p.avgPrice))

  return products.map((p) => {
    const demandLevel: "high" | "medium" | "low" =
      p.totalQty > medianQty * 1.5
        ? "high"
        : p.totalQty < medianQty * 0.5
          ? "low"
          : "medium"

    let recommendation: "increase" | "decrease" | "maintain" = "maintain"
    let reason = "Current pricing appears well-balanced for demand."

    // High demand + low price = raise opportunity
    if (demandLevel === "high" && p.avgPrice < medianPrice * 0.8) {
      recommendation = "increase"
      reason = `High demand with below-average pricing ($${p.avgPrice.toFixed(2)} vs category median $${medianPrice.toFixed(2)}). Room to increase price.`
    }
    // Low demand + high price = reduce or remove
    else if (demandLevel === "low" && p.avgPrice > medianPrice * 1.2) {
      recommendation = "decrease"
      reason = `Low demand with above-average pricing. Consider lowering price or discontinuing.`
    }
    // Declining trend
    else if (p.monthlyTrend.length >= 3) {
      const recent = p.monthlyTrend.slice(-2)
      const earlier = p.monthlyTrend.slice(0, -2)
      const recentAvgQty =
        recent.reduce((s, m) => s + m.qty, 0) / recent.length
      const earlierAvgQty =
        earlier.reduce((s, m) => s + m.qty, 0) / Math.max(1, earlier.length)
      if (recentAvgQty < earlierAvgQty * 0.6) {
        recommendation = "decrease"
        reason = `Sales volume has declined significantly. Consider a price reduction or promotional pricing.`
      } else if (recentAvgQty > earlierAvgQty * 1.4) {
        recommendation = "increase"
        reason = `Demand is growing. There may be room for a modest price increase.`
      }
    }

    return {
      item: p.item,
      category: p.category,
      avgPrice: p.avgPrice,
      totalQty: p.totalQty,
      totalRevenue: p.totalRevenue,
      demandLevel,
      recommendation,
      reason,
    }
  })
}

function getMedian(values: number[]): number {
  if (values.length === 0) return 0
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2
}

export function getAvgTransactionTrend(
  products: ProductSummary[]
): { month: string; avgValue: number }[] {
  const monthMap = new Map<string, { label: string; totalRev: number; totalQty: number }>()

  for (const p of products) {
    for (const m of p.monthlyTrend) {
      // Parse the "MMM yyyy" label back to a sortable key
      const parsed = new Date(m.month)
      const sortKey = isNaN(parsed.getTime())
        ? m.month
        : `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, "0")}`
      if (!monthMap.has(sortKey)) {
        monthMap.set(sortKey, { label: m.month, totalRev: 0, totalQty: 0 })
      }
      const entry = monthMap.get(sortKey)!
      entry.totalRev += m.revenue
      entry.totalQty += m.qty
    }
  }

  return Array.from(monthMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, data]) => ({
      month: data.label,
      avgValue: data.totalQty > 0 ? data.totalRev / data.totalQty : 0,
    }))
}
