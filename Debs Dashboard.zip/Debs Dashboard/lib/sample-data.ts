import type { BankTransaction, SquareItem } from "@/lib/types"

const SQUARE_PRODUCTS = [
  // Food & Beverages
  { item: "Draft Beer", category: "Food & Beverages", basePrice: 6, popularity: 0.9 },
  { item: "Craft IPA", category: "Food & Beverages", basePrice: 8, popularity: 0.7 },
  { item: "House Wine", category: "Food & Beverages", basePrice: 9, popularity: 0.6 },
  { item: "Soda", category: "Food & Beverages", basePrice: 3, popularity: 0.8 },
  { item: "Nachos", category: "Food & Beverages", basePrice: 12, popularity: 0.75 },
  { item: "Burger Basket", category: "Food & Beverages", basePrice: 14, popularity: 0.65 },
  { item: "Wings Platter", category: "Food & Beverages", basePrice: 13, popularity: 0.7 },
  { item: "Fries", category: "Food & Beverages", basePrice: 5, popularity: 0.85 },
  // Membership & Events
  { item: "Annual Membership", category: "Membership & Events", basePrice: 120, popularity: 0.3 },
  { item: "Monthly Dues", category: "Membership & Events", basePrice: 25, popularity: 0.5 },
  { item: "Event Ticket - Live Music", category: "Membership & Events", basePrice: 15, popularity: 0.6 },
  { item: "Event Ticket - Trivia Night", category: "Membership & Events", basePrice: 10, popularity: 0.7 },
  { item: "Room Rental", category: "Membership & Events", basePrice: 200, popularity: 0.15 },
  { item: "Guest Pass", category: "Membership & Events", basePrice: 5, popularity: 0.4 },
  // Merchandise
  { item: "Club T-Shirt", category: "Merchandise", basePrice: 25, popularity: 0.35 },
  { item: "Club Hat", category: "Merchandise", basePrice: 20, popularity: 0.25 },
  { item: "Pint Glass", category: "Merchandise", basePrice: 10, popularity: 0.45 },
  { item: "Sticker Pack", category: "Merchandise", basePrice: 5, popularity: 0.5 },
  { item: "Koozie", category: "Merchandise", basePrice: 4, popularity: 0.4 },
  { item: "Club Hoodie", category: "Merchandise", basePrice: 45, popularity: 0.2 },
]

const BANK_EXPENSE_TEMPLATES = [
  { desc: "SYSCO FOODS", amount: -850, freq: 4 },
  { desc: "RENT PAYMENT - MAIN ST", amount: -2200, freq: 1 },
  { desc: "ELECTRIC COMPANY", amount: -320, freq: 1 },
  { desc: "WATER UTILITY", amount: -85, freq: 1 },
  { desc: "COMCAST INTERNET", amount: -120, freq: 1 },
  { desc: "STATE FARM INSURANCE", amount: -450, freq: 1 },
  { desc: "SQUARE INC - DEPOSIT", amount: 0, freq: 4 },
  { desc: "QUICKBOOKS SUBSCRIPTION", amount: -35, freq: 1 },
  { desc: "SPOTIFY BUSINESS", amount: -15, freq: 1 },
  { desc: "ZOOM PRO", amount: -20, freq: 1 },
  { desc: "AMAZON SUPPLIES", amount: -150, freq: 2 },
  { desc: "SERVICE CHARGE", amount: -12, freq: 1 },
  { desc: "COSTCO WHOLESALE", amount: -400, freq: 2 },
  { desc: "PEPSI BEVERAGES", amount: -280, freq: 2 },
  { desc: "ADP PAYROLL", amount: -3500, freq: 2 },
  { desc: "OFFICE DEPOT", amount: -75, freq: 1 },
]

function randomVariation(base: number, pct: number): number {
  return base * (1 + (Math.random() - 0.5) * 2 * pct)
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Seasonal multiplier for social clubs (higher in summer and holidays)
function seasonMultiplier(month: number): number {
  const multipliers = [
    0.7, 0.65, 0.8, 0.9, 1.0, 1.2, 1.3, 1.25, 1.1, 1.0, 0.85, 1.15,
  ]
  return multipliers[month]
}

export function generateSampleSquareData(): SquareItem[] {
  const items: SquareItem[] = []
  const now = new Date()

  for (let monthsAgo = 11; monthsAgo >= 0; monthsAgo--) {
    const year = now.getFullYear()
    const month = now.getMonth() - monthsAgo
    const d = new Date(year, month, 1)
    const daysInMonth = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()
    const seasonMult = seasonMultiplier(d.getMonth())

    for (const product of SQUARE_PRODUCTS) {
      // Calculate how many sales this month for this product
      const baseSales = Math.round(product.popularity * 30 * seasonMult)
      const numSales = Math.max(1, Math.round(randomVariation(baseSales, 0.3)))

      // Spread sales across the month
      for (let s = 0; s < numSales; s++) {
        const day = Math.min(daysInMonth, Math.max(1, randomInt(1, daysInMonth)))
        const hour = randomInt(11, 22)
        const minute = randomInt(0, 59)
        const price = randomVariation(product.basePrice, 0.05)
        const qty = product.basePrice > 50 ? 1 : randomInt(1, 3)
        const gross = price * qty
        const discount = Math.random() < 0.1 ? gross * 0.1 : 0

        items.push({
          date: new Date(d.getFullYear(), d.getMonth(), day),
          time: `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`,
          item: product.item,
          category: product.category,
          qty,
          grossSales: Math.round(gross * 100) / 100,
          discounts: Math.round(discount * 100) / 100,
          netSales: Math.round((gross - discount) * 100) / 100,
          tax: Math.round(gross * 0.08 * 100) / 100,
        })
      }
    }
  }

  return items.sort((a, b) => a.date.getTime() - b.date.getTime())
}

export function generateSampleBankData(): BankTransaction[] {
  const transactions: BankTransaction[] = []
  const now = new Date()
  let balance = 15000

  for (let monthsAgo = 11; monthsAgo >= 0; monthsAgo--) {
    const year = now.getFullYear()
    const month = now.getMonth() - monthsAgo
    const d = new Date(year, month, 1)
    const daysInMonth = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()

    for (const template of BANK_EXPENSE_TEMPLATES) {
      for (let f = 0; f < template.freq; f++) {
        const day = Math.min(
          daysInMonth,
          Math.max(1, template.freq === 1 ? randomInt(1, 5) : randomInt(1, daysInMonth))
        )

        let amount: number
        if (template.desc.includes("SQUARE INC")) {
          // Square deposits -- variable based on sales
          amount = randomVariation(3500 * seasonMultiplier(d.getMonth()), 0.2)
        } else {
          amount = randomVariation(template.amount, 0.1)
        }

        balance += amount
        transactions.push({
          date: new Date(d.getFullYear(), d.getMonth(), day),
          description: template.desc,
          amount: Math.round(amount * 100) / 100,
          balance: Math.round(balance * 100) / 100,
        })
      }
    }

    // Add a few cash deposits
    const cashDeposits = randomInt(1, 3)
    for (let c = 0; c < cashDeposits; c++) {
      const amount = randomVariation(500, 0.4)
      balance += amount
      transactions.push({
        date: new Date(
          d.getFullYear(),
          d.getMonth(),
          randomInt(1, daysInMonth)
        ),
        description: "CASH DEPOSIT",
        amount: Math.round(amount * 100) / 100,
        balance: Math.round(balance * 100) / 100,
      })
    }

    // Member dues deposits
    const duesDeposits = randomInt(5, 15)
    for (let m = 0; m < duesDeposits; m++) {
      const amount = randomVariation(25, 0.1)
      balance += amount
      transactions.push({
        date: new Date(
          d.getFullYear(),
          d.getMonth(),
          randomInt(1, 10)
        ),
        description: "MEMBER DUES PAYMENT",
        amount: Math.round(amount * 100) / 100,
        balance: Math.round(balance * 100) / 100,
      })
    }
  }

  return transactions.sort((a, b) => a.date.getTime() - b.date.getTime())
}
