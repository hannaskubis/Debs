// ── Bank Transaction ──
export interface BankTransaction {
  date: Date
  description: string
  amount: number // positive = deposit, negative = expense
  balance: number | null
}

// ── Square Item Sale ──
export interface SquareItem {
  date: Date
  time: string
  item: string
  category: string
  qty: number
  grossSales: number
  discounts: number
  netSales: number
  tax: number
}

// ── Aggregated product ──
export interface ProductSummary {
  item: string
  category: string
  totalQty: number
  totalRevenue: number
  avgPrice: number
  monthlyTrend: { month: string; qty: number; revenue: number }[]
}

// ── Monthly financial summary ──
export interface MonthlySummary {
  month: string // "YYYY-MM"
  label: string // "Jan 2025"
  revenue: number
  expenses: number
  netFlow: number
  deposits: number
  depositCount: number
}

// ── Category breakdown ──
export interface CategoryBreakdown {
  category: string
  revenue: number
  qty: number
  percentage: number
}

// ── Spending category ──
export interface SpendingCategory {
  category: string
  total: number
  count: number
  avgAmount: number
  trend: "rising" | "falling" | "stable"
  monthlyAmounts: { month: string; amount: number }[]
}

// ── Deposit analysis ──
export interface DepositAnalysis {
  date: Date
  amount: number
  daysSinceLast: number | null
}

// ── Pricing recommendation ──
export interface PricingInsight {
  item: string
  category: string
  avgPrice: number
  totalQty: number
  totalRevenue: number
  demandLevel: "high" | "medium" | "low"
  recommendation: "increase" | "decrease" | "maintain"
  reason: string
}

// ── Dashboard data state ──
export interface DashboardData {
  bankTransactions: BankTransaction[]
  squareItems: SquareItem[]
  dateRange: { start: Date; end: Date } | null
}

// ── Column mapping ──
export interface ColumnMapping {
  [expectedField: string]: string // maps our field name -> CSV column name
}
