import Papa from "papaparse"
import type { BankTransaction, ColumnMapping } from "@/lib/types"

const FIELD_ALIASES: Record<string, string[]> = {
  date: ["date", "transaction date", "trans date", "posting date", "post date"],
  description: [
    "description",
    "memo",
    "details",
    "transaction description",
    "narrative",
    "payee",
    "name",
  ],
  amount: ["amount", "transaction amount", "trans amount"],
  debit: ["debit", "withdrawal", "withdrawals", "debit amount"],
  credit: ["credit", "deposit", "deposits", "credit amount"],
  balance: ["balance", "running balance", "ledger balance", "available balance"],
}

function normalizeHeader(header: string): string {
  return header.trim().toLowerCase().replace(/[^a-z0-9 ]/g, "")
}

export function detectBankColumns(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {}
  const normalized = headers.map(normalizeHeader)

  for (const [field, aliases] of Object.entries(FIELD_ALIASES)) {
    const idx = normalized.findIndex((h) => aliases.includes(h))
    if (idx !== -1) {
      mapping[field] = headers[idx]
    }
  }

  return mapping
}

function parseAmount(val: unknown): number {
  if (val === null || val === undefined || val === "") return 0
  const str = String(val).replace(/[$,()]/g, "").trim()
  if (str.startsWith("(") || str.endsWith(")")) {
    return -Math.abs(parseFloat(str.replace(/[()]/g, "")) || 0)
  }
  return parseFloat(str) || 0
}

function parseDate(val: unknown): Date {
  if (val instanceof Date) return val
  const str = String(val).trim()
  const d = new Date(str)
  if (!isNaN(d.getTime())) return d
  // Try MM/DD/YYYY
  const parts = str.split(/[/-]/)
  if (parts.length === 3) {
    const [m, day, y] = parts.map(Number)
    return new Date(y < 100 ? y + 2000 : y, m - 1, day)
  }
  return new Date()
}

export function parseBankData(
  rows: Record<string, unknown>[],
  mapping: ColumnMapping
): BankTransaction[] {
  return rows
    .filter((row) => {
      const dateVal = row[mapping.date]
      return dateVal !== null && dateVal !== undefined && String(dateVal).trim() !== ""
    })
    .map((row) => {
      let amount: number
      if (mapping.amount) {
        amount = parseAmount(row[mapping.amount])
      } else {
        const credit = parseAmount(row[mapping.credit])
        const debit = parseAmount(row[mapping.debit])
        amount = credit > 0 ? credit : -Math.abs(debit)
      }

      return {
        date: parseDate(row[mapping.date]),
        description: String(row[mapping.description] || "").trim(),
        amount,
        balance: mapping.balance ? parseAmount(row[mapping.balance]) : null,
      }
    })
    .sort((a, b) => a.date.getTime() - b.date.getTime())
}

export async function parseBankFile(
  file: File
): Promise<{ headers: string[]; rows: Record<string, unknown>[] }> {
  const ext = file.name.split(".").pop()?.toLowerCase()

  if (ext === "xlsx" || ext === "xls") {
    const XLSX = await import("xlsx")
    const buffer = await file.arrayBuffer()
    const wb = XLSX.read(buffer, { type: "array", cellDates: true })
    const ws = wb.Sheets[wb.SheetNames[0]]
    const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws)
    const headers = json.length > 0 ? Object.keys(json[0]) : []
    return { headers, rows: json }
  }

  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const rows = result.data as Record<string, unknown>[]
        const headers = result.meta.fields || []
        resolve({ headers, rows })
      },
      error: (err) => reject(err),
    })
  })
}
