import Papa from "papaparse"
import type { SquareItem, ColumnMapping } from "@/lib/types"

const FIELD_ALIASES: Record<string, string[]> = {
  date: ["date", "transaction date", "trans date"],
  time: ["time", "transaction time"],
  item: ["item", "item name", "product", "product name", "name"],
  category: ["category", "item category", "product category", "type"],
  qty: ["qty", "quantity", "units", "unit qty", "count"],
  grossSales: [
    "gross sales",
    "gross amount",
    "total",
    "amount",
    "sales",
    "price",
  ],
  discounts: ["discounts", "discount", "discount amount"],
  netSales: ["net sales", "net amount", "net total", "net"],
  tax: ["tax", "tax amount", "taxes"],
}

function normalizeHeader(header: string): string {
  return header.trim().toLowerCase().replace(/[^a-z0-9 ]/g, "")
}

export function detectSquareColumns(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {}
  const normalized = headers.map(normalizeHeader)

  for (const [field, aliases] of Object.entries(FIELD_ALIASES)) {
    const idx = normalized.findIndex((h) => aliases.includes(h))
    if (idx !== -1) {
      mapping[field] = headers[idx]
    }
  }

  return mapping
}

function parseNumber(val: unknown): number {
  if (val === null || val === undefined || val === "") return 0
  const str = String(val).replace(/[$,]/g, "").trim()
  return parseFloat(str) || 0
}

function parseDate(val: unknown): Date {
  if (val instanceof Date) return val
  const str = String(val).trim()
  const d = new Date(str)
  if (!isNaN(d.getTime())) return d
  const parts = str.split(/[/-]/)
  if (parts.length === 3) {
    const [m, day, y] = parts.map(Number)
    return new Date(y < 100 ? y + 2000 : y, m - 1, day)
  }
  return new Date()
}

export function parseSquareData(
  rows: Record<string, unknown>[],
  mapping: ColumnMapping
): SquareItem[] {
  return rows
    .filter((row) => {
      const itemVal = row[mapping.item]
      return itemVal !== null && itemVal !== undefined && String(itemVal).trim() !== ""
    })
    .map((row) => ({
      date: parseDate(row[mapping.date]),
      time: String(row[mapping.time] || "").trim(),
      item: String(row[mapping.item] || "").trim(),
      category: String(row[mapping.category] || "Uncategorized").trim(),
      qty: Math.max(1, Math.round(parseNumber(row[mapping.qty]))),
      grossSales: parseNumber(row[mapping.grossSales]),
      discounts: parseNumber(row[mapping.discounts]),
      netSales: mapping.netSales
        ? parseNumber(row[mapping.netSales])
        : parseNumber(row[mapping.grossSales]) -
          parseNumber(row[mapping.discounts]),
      tax: parseNumber(row[mapping.tax]),
    }))
    .sort((a, b) => a.date.getTime() - b.date.getTime())
}

export async function parseSquareFile(
  file: File
): Promise<{ headers: string[]; rows: Record<string, unknown>[] }> {
  const ext = file.name.split(".").pop()?.toLowerCase()

  if (ext === "xlsx" || ext === "xls") {
    const XLSX = await import("xlsx")
    const buffer = await file.arrayBuffer()
    const wb = XLSX.read(buffer, { type: "array", cellDates: true })
    const ws = wb.Sheets[wb.SheetNames[0]]
    const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws)
    const headers = json.length > 0 ? Object.keys(json[0]) : []
    return { headers, rows: json }
  }

  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const rows = result.data as Record<string, unknown>[]
        const headers = result.meta.fields || []
        resolve({ headers, rows })
      },
      error: (err) => reject(err),
    })
  })
}
